__version__ = '0.1'

from .resume_generator import ResumeGenerator
from .style_manager import StyleManager
from .manager_facade import FacadeManager
from .resume import Resume